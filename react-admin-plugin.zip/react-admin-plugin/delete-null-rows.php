<?php
// Load WordPress environment
require_once('../../../wp-load.php');

// Ensure the request is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.0 405 Method Not Allowed');
    echo 'Method Not Allowed';
    exit;
}

// Ensure user is logged in and has the required capability
if (!is_user_logged_in() || !current_user_can('manage_options')) {
    header('HTTP/1.0 403 Forbidden');
    echo 'Forbidden';
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'owner';

// Example query to delete rows with NULL or blank values in a specific column
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM $table_name WHERE Mobile IS NULL OR Mobile = '' OR Mobile = 'null'"
    )
);
$wpdb->query(
    $wpdb->prepare(
        "UPDATE $table_name set `Mobile`= REGEXP_REPLACE(`Mobile`, '[\]\\[!@#$%.&*`~^_{}:;<>/\\|()-]+', '')"
    )
);

header('Content-Type: application/json');
echo json_encode(['message' => 'Rows deleted successfully.']);
exit;
