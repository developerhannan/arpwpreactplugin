<?php
// Load WordPress environment
require_once('../../../wp-load.php');

// Ensure the request is a POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.0 405 Method Not Allowed');
    echo 'Method Not Allowed';
    exit;
}

// Ensure user is logged in and has the required capability
if (!is_user_logged_in() || !current_user_can('manage_options')) {
    header('HTTP/1.0 403 Forbidden');
    echo 'Forbidden';
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'owner'; 

// Example query to update rows   in a specific column
 
$wpdb->query(
    $wpdb->prepare(
        "UPDATE wp_owner JOIN wp_community ON wp_owner.Tower LIKE  CONCAT('%', wp_community.NAME, '%')  SET wp_owner.Tower = wp_community.NAME, wp_owner.Tower_Slug = wp_community.SLUG"
    )
); 

header('Content-Type: application/json');
echo json_encode(['message' => 'Rows updated successfully.']);
exit;
