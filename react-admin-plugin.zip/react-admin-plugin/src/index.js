import React from 'react';
import ReactDOM from 'react-dom';
import Menu from './components/Menu';
import Tabs from './components/Tabs';

const App = () => {
  return (
    <div className="app">
     
      <Tabs />
    </div>
  );
}

ReactDOM.render(<App />, document.getElementById('react-admin-app'));
