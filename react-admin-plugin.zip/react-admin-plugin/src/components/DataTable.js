import React, { useEffect, useState } from 'react';
import { useTable, usePagination, useGlobalFilter } from 'react-table';
import './DataTable.css';

const DataTable = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await fetch('../wp-content/plugins/react-admin-plugin/fetch-rows.php');
                const result = await response.json();
                setData(result);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, []);

    const columns = React.useMemo(
        () => [
            {
                Header: 'Location',
                accessor: 'Location',  
            },
            {
                Header: 'Sub Location',
                accessor: 'Sub Location',  
            },
            {
                Header: 'Tower',
                accessor: 'Tower',  
            },
            {
                Header: 'Tower_Slug',
                accessor: 'Tower_Slug ',  
            },
            {
                Header: 'Size',
                accessor: 'Size',  
            },
            {
                Header: 'Flat',
                accessor: 'Flat',  
            },
            {
                Header: 'Client Type',
                accessor: 'Client Type',  
            },
            {
                Header: 'Name',
                accessor: 'Name',  
            },
            {
                Header: 'Mobile',
                accessor: 'Mobile',  
            },
            {
                Header: 'Nationality',
                accessor: 'Nationality',  
            },
            // Add more columns as needed
        ],
        []
    );

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        page, // Instead of rows, we use page,
        prepareRow,
        setGlobalFilter,
        state: { pageIndex, pageSize, globalFilter },
        previousPage,
        nextPage,
        canPreviousPage,
        canNextPage,
        pageOptions,
        setPageSize,
    } = useTable(
        {
            columns,
            data,
            initialState: { pageIndex: 0, pageSize: 10 }, // initial page size
        },
        useGlobalFilter,
        usePagination
    );

    return (
        <div>
            <br />
            <input
                value={globalFilter || ''}
                onChange={(e) => setGlobalFilter(e.target.value)}
                placeholder="Search..."
                style={{ marginBottom: '10px' }}
            />
            <table {...getTableProps()} className="data-table">
                <thead>
                    {headerGroups.map(headerGroup => (
                        <tr {...headerGroup.getHeaderGroupProps()}>
                            {headerGroup.headers.map(column => (
                                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
                            ))}
                        </tr>
                    ))}
                </thead>
                <tbody {...getTableBodyProps()}>
                    {page.map(row => {
                        prepareRow(row);
                        return (
                            <tr {...row.getRowProps()}>
                                {row.cells.map(cell => (
                                    <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                ))}
                            </tr>
                        );
                    })}
                </tbody>
            </table>
            <div className="pagination">
                <button onClick={() => previousPage()} disabled={!canPreviousPage}>
                    Previous
                </button>
                <span>
                    Page{' '}
                    <strong>
                        {pageIndex + 1} of {pageOptions.length}
                    </strong>
                </span>
                <button onClick={() => nextPage()} disabled={!canNextPage}>
                    Next
                </button>
                <select
                    value={pageSize}
                    onChange={(e) => setPageSize(Number(e.target.value))}
                >
                    {[10, 20, 30, 40, 50].map(size => (
                        <option key={size} value={size}>
                            Show {size}
                        </option>
                    ))}
                </select>
            </div>
        </div>
    );
};

export default DataTable;
