import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const CSVImporter = ({ onSuccess }) => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };
  const handleSuccess = () => {
    // Simulate a successful operation, such as an API call
    console.log('Operation successful!');
    onSuccess();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) {
      alert('Please select a CSV file.');
      return;
    }

    const formData = new FormData();
    formData.append('csv_file', file);

    setUploading(true);

    try {
      const response = await fetch('../wp-content/plugins/react-admin-plugin/importcsv.php', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setUploadSuccess(true);
        setUploadError('');
      } else {
        const errorMessage = await response.text();
        setUploadSuccess(false);
        setUploadError(errorMessage);
      }
    } catch (error) {
      console.error('Error uploading CSV:', error);
      setUploadSuccess(false);
      setUploadError('An error occurred while uploading CSV.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="container mt-5">
      <h2>Upload CSV</h2>
      <form onSubmit={handleSubmit}>
        <input   type="file" accept=".csv" onChange={handleFileChange} />
        <button className="btn btn-primary" type="submit" disabled={uploading}  >
          Upload
        </button>
      </form>
      {uploading && <progress max="100" />}
      {uploadSuccess && <div style={{ color: 'green' }} >CSV data uploaded successfully! </div>}
      {uploadError && <div style={{ color: 'red' }}>Error: {uploadError}</div>}
      <button className="btn btn-primary" onClick={handleSuccess}>Clic to map fields</button>
    </div>
  );
};

export default CSVImporter;
