import React from 'react';

const Menu = () => {
  return (
    <div className="menu">
      <h2>Admin Menu</h2>
      
    </div>
  );
}

export default Menu;
