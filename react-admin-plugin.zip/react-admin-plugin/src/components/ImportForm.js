import React, { useState } from 'react';
import { Button, Form, Alert, ProgressBar } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';


function ImportData() {
    const [jsonUrl, setJsonUrl] = useState('');
    const [message, setMessage] = useState('');
    const [progress, setProgress] = useState(0);
    const [isLoading, setIsLoading] = useState(false);
    const [isSuccess, setIsSuccess] = useState(false);

    const handleSubmit = async (event) => {
        event.preventDefault();
        setMessage('');
        setProgress(0);
        setIsLoading(true);
        setIsSuccess(false);

        try {
            const response = await fetch('../wp-content/plugins/react-admin-plugin/uploadjson.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ jsonUrl }),
            });

            const data = await response.json();

            if (response.ok) {
                setIsSuccess(true);
                setMessage(data.message || 'Data imported successfully');
            } else {
                setIsSuccess(false);
                setMessage(`Error: ${data.error || 'An unexpected error occurred'}`);
            }
        } catch (error) {
            setIsSuccess(false);
            setMessage(`Error: ${error.message}`);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="container mt-5">
            <h2>Import Data to WordPress MySQL Table</h2>
            <Form onSubmit={handleSubmit}>
                <Form.Group controlId="jsonUrl">
                    <Form.Label>JSON URL:</Form.Label>
                    <Form.Control
                        type="text"
                        value={jsonUrl}
                        onChange={(e) => setJsonUrl(e.target.value)}
                    />
                </Form.Group>
                <br />
                <Button type="submit" disabled={isLoading}>
                    {isLoading ? 'Importing...' : 'Import'}
                </Button>
            </Form>
            {isLoading && (
                <ProgressBar 
                    now={progress} 
                    label={`${progress}%`} 
                    className="mt-3" 
                    animated 
                    striped 
                
                    style={{color: "green"}}
                    />
            )}
            {message && (
                <Alert variant={isSuccess ? 'success' : 'danger'} className="mt-3">
                    {message}
                </Alert>
            )}
        </div>
    );
}

export default ImportData;
