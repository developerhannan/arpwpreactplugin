import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const UpdateRows = () => {
    const [status, setStatus] = useState('');

    const handleDelete = async () => {
        try {
            const response = await fetch('../wp-content/plugins/react-admin-plugin/update-rows.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (response.ok) {
                setStatus('Rows successfully updated.');
            } else {
                setStatus('Failed to update rows.');
            }
        } catch (error) {
            console.error('Error:', error);
            setStatus('An error occurred.');
        }
    };

    return (
        <div>
            <button onClick={handleDelete} className="btn btn-primary">Update Tower Names and Slug</button>
            <p>{status}</p>
        </div>
    );
};

export default UpdateRows;
