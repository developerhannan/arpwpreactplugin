import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const DeleteNullRows = () => {
    const [status, setStatus] = useState('');

    const handleDelete = async () => {
        try {
            const response = await fetch('../wp-content/plugins/react-admin-plugin/delete-null-rows.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (response.ok) {
                setStatus('Rows successfully deleted.');
            } else {
                setStatus('Failed to delete rows.');
            }
        } catch (error) {
            console.error('Error:', error);
            setStatus('An error occurred.');
        }
    };

    return (
        <div>
            <br />
            <button onClick={handleDelete} className="btn btn-primary">Delete Null or Blank Rows</button>
            <p>{status}</p>
        </div>
    );
};

export default DeleteNullRows;
