import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const CSVUploader = () => {
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [headers, setHeaders] = useState([]);
  const [fieldMapping, setFieldMapping] = useState({});
  const [defaultValues, setDefaultValues] = useState({});

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleMappingChange = (dbField, csvHeader) => {
    setFieldMapping({
      ...fieldMapping,
      [dbField]: csvHeader,
    });
  };

  const handleDefaultValueChange = (dbField, value) => {
    setDefaultValues({
      ...defaultValues,
      [dbField]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) {
      alert('Please select a CSV file.');
      return;
    }

    const formData = new FormData();
    formData.append('csv_file', file);
    formData.append('field_mapping', JSON.stringify(fieldMapping));
    formData.append('default_values', JSON.stringify(defaultValues));

    setUploading(true);

    try {
      const response = await fetch('../wp-content/plugins/react-admin-plugin/uploadcsv.php', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setUploadSuccess(true);
        setUploadError('');
      } else {
        const errorMessage = await response.text();
        setUploadSuccess(false);
        setUploadError(errorMessage);
      }
    } catch (error) {
      console.error('Error uploading CSV:', error);
      setUploadSuccess(false);
      setUploadError('An error occurred while uploading CSV.');
    } finally {
      setUploading(false);
    }
  };

  const parseCSVHeaders = async (file) => {
    const reader = new FileReader();
    reader.onload = () => {
      const text = reader.result;
      const lines = text.split('\n');
      if (lines.length > 0) {
        const headers = lines[0].split(',');
        setHeaders(headers);
      }
    };
    reader.readAsText(file);
  };

  useEffect(() => {
    if (file) {
      parseCSVHeaders(file);
    }
  }, [file]);

  return (
    <div className="container mt-5">
      <h2>Upload CSV</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <input type="file" className="form-control" accept=".csv" onChange={handleFileChange} />
        </div>
        
        {headers.length > 0 && ( 

          <div className="mt-4">
            <h3>Map Fields</h3>
            {[`Location`, `Sub Location`, `Tower`, `Tower_Slug`, `Size`, `Flat`, `Client Type`, `Name`, `Mobile`, `Nationality`, `is_clean`].map((dbField) => (
              <div className="form-row" key={dbField}>

<Container> 
<Row>
  <Col>    <label className="sr-only" htmlFor={`select-${dbField}`}>{dbField}</label> </Col>
  <Col>
  
  <select
                    id={`select-${dbField}`}
                    className="form-control"
                    onChange={(e) => handleMappingChange(dbField, e.target.value)}
                  >
                    <option value="">Select CSV Header</option>
                    {headers.map((header) => (
                      <option key={header} value={header}>
                        {header}
                      </option>
                    ))}
                  </select>
  </Col>
  <Col>
  <input
                    type="text"
                    className="form-control"
                    placeholder="Default Value"
                    onChange={(e) => handleDefaultValueChange(dbField, e.target.value)}
                  />
  </Col>
</Row>
</Container>

             
 
              </div>
            ))}
          </div>
        )}
        <br />
        <button type="submit" className="btn btn-primary" disabled={uploading}>
          Upload
        </button>
      </form>
      {uploading && <progress max="100" className="mt-3" />}
      {uploadSuccess && <div className="alert alert-success mt-3">CSV data uploaded successfully!</div>}
      {uploadError && <div className="alert alert-danger mt-3">Error: {uploadError}</div>}
    </div>
  );
};

export default CSVUploader;
