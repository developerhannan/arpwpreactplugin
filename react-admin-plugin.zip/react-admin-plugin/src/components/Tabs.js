import React, { useState } from 'react';
import ImportForm from './ImportForm';
import CSVUploader from './CSVUploader';
import CSVImporter from './CSVImporter';
import DeleteNullRows from './DeleteNullRows';
import UpdateRows from './UpdateRows';
import DataTable from './DataTable';

function Tab(props) {
  const isActive = props.activeTab === props.label;
  return isActive ? <div>{props.children}</div> : null;


}

function Tabs(props) {
  const [activeTab, setActiveTab] = useState(props.defaultTab);


  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div>
      <div>
        {props.tabs.map((tab) => (
          <button key={tab} onClick={() => handleTabClick(tab)}>
            {tab}
          </button>
        ))}
      </div>
      {props.children.map((child) => React.cloneElement(child, { activeTab }))}
    </div>
  );
}

function App() { 
  const [isOperationSuccessful, setIsOperationSuccessful] = useState(false);

  const handleSuccess = () => {
    setIsOperationSuccessful(true);
  }; 
  
  return (
    <Tabs defaultTab="Fetch Communities" id="controlled-tabs" selectedTabClassName="bg-white"  tabs={['Fetch Communities', 'Import Owners', 'Clean Up', 'Market Analysis']}>
      <Tab label="Fetch Communities" activeTab="Fetch Communities">
      <ImportForm />
         
      </Tab>
      <Tab label="Import Owners" activeTab="Import Owners">
      {!isOperationSuccessful ? (
        <CSVImporter onSuccess={handleSuccess} />
      ) : (
      
        <CSVUploader />
      )}
     
      </Tab>
      <Tab label="Clean Up" activeTab="Clean Up">
        
        <DeleteNullRows />
        <UpdateRows />
      </Tab>
      <Tab label="Market Analysis" activeTab="Market Analysis">
      <DataTable />
      </Tab>
    </Tabs>
  );
}

export default App;
