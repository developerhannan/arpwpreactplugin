import React, { useState } from 'react';

function Tab(props) {
  const isActive = props.activeTab === props.label;
  return isActive ? <div>{props.children}</div> : null;


}

function Tabs(props) {
  const [activeTab, setActiveTab] = useState(props.defaultTab);


  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  return (
    <div>
      <div>
        {props.tabs.map((tab) => (
          <button key={tab} onClick={() => handleTabClick(tab)}>
            {tab}
          </button>
        ))}
      </div>
      {props.children.map((child) => React.cloneElement(child, { activeTab }))}
    </div>
  );
}

function App() {  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [uploadError, setUploadError] = useState('');

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) {
      alert('Please select a CSV file.');
      return;
    }

    const formData = new FormData();
    formData.append('csv_file', file);

    setUploading(true);

    try {
      const response = await fetch('http://localhost/wordpress/uploadcsv.php', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        setUploadSuccess(true);
        setUploadError('');
      } else {
        const errorMessage = await response.text();
        setUploadSuccess(false);
        setUploadError(errorMessage);
      }
    } catch (error) {
      console.error('Error uploading CSV:', error);
      setUploadSuccess(false);
      setUploadError('An error occurred while uploading CSV.');
    } finally {
      setUploading(false);
    }
  };
  return (
    <Tabs defaultTab="Tab 1" id="controlled-tabs" selectedTabClassName="bg-white"  tabs={['Tab 1', 'Tab 2', 'Tab 3', 'Tab 4']}>
      <Tab label="Tab 1" activeTab="Tab 1">
      <h2>Upload CSV</h2>
      <form onSubmit={handleSubmit}>
        <input type="file" accept=".csv" onChange={handleFileChange} />
        <button type="submit">Upload</button>
      </form>
         
      </Tab>
      <Tab label="Tab 2" activeTab="Tab 2">
        Content for Tab 2
      </Tab>
      <Tab label="Tab 3" activeTab="Tab 3">
        Content for Tab 3
      </Tab>
      <Tab label="Tab 4" activeTab="Tab 4">
        Content for Tab 4
      </Tab>
    </Tabs>
  );
}

export default App;
