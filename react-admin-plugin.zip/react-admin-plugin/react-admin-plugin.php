<?php
/**
 * Plugin Name: ARP Assessment
 * Description: A WordPress plugin with a React-based admin  for ARP Assessment.
 */

// Enqueue React scripts and styles
function react_admin_enqueue_scripts() {
    wp_enqueue_script('react-admin-main', plugins_url('/build/index.js', __FILE__), array(), '1.0', true);
    wp_enqueue_style('react-admin-styles', plugins_url('/build/index.css', __FILE__), array(), '1.0');
}
add_action('admin_enqueue_scripts', 'react_admin_enqueue_scripts');

 

// Create MySQL table on plugin activation
function react_admin_create_table() {
    // WP Globals
    global $table_prefix, $wpdb;

    // Owner Table
    $customerTable = $table_prefix . 'owner';

    // Create Owner Table if not exist
    if( $wpdb->get_var( "show tables like '$customerTable'" ) != $customerTable ) {

        // Query - Create Table
        $sql = "CREATE TABLE `$customerTable` (";
        $sql .= " `id` int(11) NOT NULL auto_increment, ";
        $sql .= " `Location` varchar(500) NOT NULL, ";
        $sql .= " `Sub Location` varchar(500) NOT NULL, ";
        $sql .= " `Tower` varchar(500), ";
        $sql .= " `Tower_Slug` varchar(500) NOT NULL, ";
        $sql .= " `Size` varchar(500), ";
        $sql .= " `Flat` varchar(500), ";
        $sql .= " `Client Type` varchar(150) NOT NULL, ";
        $sql .= " `Name` varchar(150), ";
        $sql .= " `Mobile` varchar(15), ";
        $sql .= " `Nationality` varchar(5) NOT NULL, ";
        $sql .= " `is_clean` varchar(5) NOT NULL, ";
        $sql .= " `Last_Update_Date` varchar(5) NOT NULL, ";

        $sql .= " PRIMARY KEY `customer_id` (`id`) ";
        $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";

        // Include Upgrade Script
        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
    
        // Create Table
        dbDelta( $sql );

}
$customerTable = $table_prefix . 'community';

    // Create Community Table if not exist
    if( $wpdb->get_var( "show tables like '$customerTable'" ) != $customerTable ) {

        // Query - Create Table
        $sql = "CREATE TABLE `$customerTable` (";
        $sql .= " `ID` int(11) NOT NULL auto_increment, ";
        $sql .= " `TYPE` varchar(500) NOT NULL, ";
        $sql .= " `NAME` varchar(500) NOT NULL, ";
        $sql .= " `SLUG` varchar(500), ";
        $sql .= " `LAST_UPDATE_DATE` varchar(500) NOT NULL, "; 
        $sql .= " PRIMARY KEY `ID` (`id`) ";
        $sql .= ") ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1;";

        // Include Upgrade Script
        require_once( ABSPATH . '/wp-admin/includes/upgrade.php' );
    
        // Create Table
        dbDelta( $sql );

}
}
register_activation_hook(__FILE__, 'react_admin_create_table');

// Drop MySQL table on plugin deactivation
function react_admin_drop_table() {
   // WP Globals
    global $table_prefix, $wpdb;

    // Customer Table
    $customerTable = $table_prefix . 'owner';

    $sql = "DROP TABLE IF EXISTS $customerTable;";

    $wpdb->query($sql);
    // Community Table
    $communityTable = $table_prefix . 'community';

    $sql1 = "DROP TABLE IF EXISTS $communityTable;";

    $wpdb->query($sql1);
}
register_deactivation_hook(__FILE__, 'react_admin_drop_table');
// Add menu in WP admin
function add_react_admin_menu() {
    add_menu_page(
        'ARP Assessment',        // Page title
        'ARP Assessment',        // Menu title
        'manage_options',            // Capability required
        'react-admin-plugin',        // Menu slug
        'render_react_admin_page'    // Callback function to render page content
    );
}
add_action('admin_menu', 'add_react_admin_menu');

// Callback function to render page content
function render_react_admin_page() {
    ?>
    <div class="wrap">
        <h1>ARP Assessment</h1>
        <div id="react-admin-app"></div>
    </div>
    <?php
}
