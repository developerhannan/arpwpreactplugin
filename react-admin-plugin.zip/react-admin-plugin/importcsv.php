<?php
// Include WordPress functionality
define('WP_USE_THEMES', false);
require_once('../../../wp-load.php');

// Check if the user is logged in and has permission
if (!is_user_logged_in() || !current_user_can('manage_options')) {
    http_response_code(403);
    die('Unauthorized access');
}

// Check if a file is uploaded
if ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    die('Error uploading file');
}

// Get the uploaded file
$csv_file = $_FILES['csv_file']['tmp_name'];

// Open the CSV file for reading
if (($handle = fopen($csv_file, 'r')) !== false) {
    // Iterate through each row in the CSV file
    while (($data = fgetcsv($handle, 1000, ',')) !== false) {
        // Assuming the CSV file has columns: id, name, email, address
        $Community = $data[1];
        $Sub_Location = $data[2];
        $Tower = $data[3]; 
        $Size = $data[4];
        $Flat = $data[5];
        $Client_Type = $data[6];
        $Name = $data[7];
        $Mobile = $data[8];
        $Nationality = $data[9]; 

        // Insert data into wp_customer table
        $wpdb->insert(
            'wp_owner',
            array(
                'Location' => $Community,
                'Sub Location' => $Sub_Location,
                'Tower' => $Tower, 
                'Size' => $Size,
                'Flat' => $Flat,
                'Client Type' => $Client_Type,
                'Name' => $Name,
                'Mobile' => $Mobile,
                'Nationality' => $Nationality
            ),
            array(
                '%s',
                '%s',
                '%s', 
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s'
            )
        );
    }
    fclose($handle);
    echo 'CSV data imported successfully';
} else {
    http_response_code(500);
    echo 'Error opening CSV file';
}
?>
