<?php
// Load WordPress environment
require_once('../../../wp-load.php');

// Set the content type to JSON
header('Content-Type: application/json');

try {
    // Get the raw POST data
    $json_data = file_get_contents('php://input');
    
    // Decode the JSON data
    $decoded_data = json_decode($json_data, true);

    // Check for JSON decoding errors
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data');
    }

    // Extract URL from the request
    $jsonUrl = $decoded_data['jsonUrl'] ?? '';

    if (empty($jsonUrl)) {
        throw new Exception('JSON URL is required');
    }

    // Fetch JSON data from the provided URL
    $json_content = file_get_contents($jsonUrl);

    if ($json_content === false) {
        throw new Exception('Error fetching JSON data from URL');
    }

    // Decode the fetched JSON data
    $data = json_decode($json_content, true);

    if ($data === null) {
        throw new Exception('Error decoding JSON data from URL');
    }

    // WordPress database global variable
    global $wpdb;

    // WordPress table name
    $table_name = $wpdb->prefix . 'community';

    // Loop through JSON data and insert into the WordPress table
    foreach ($data as $item) {
        $wpdb->insert(
            $table_name,
            array(
                'ID' => $item['id'],
                'TYPE' => $item['l_t'],
                'NAME' => $item['n'],
                'SLUG' => $item['en_s']
            ),
            array(
                '%s',  
                '%s',  
                '%s',
                '%s' 
            )
        );

        // Check for insertion errors
        if ($wpdb->last_error) {
            throw new Exception('Database error: ' . $wpdb->last_error);
        }
    }

    // Send a success response
    echo json_encode(['message' => 'Data imported successfully']);
} catch (Exception $e) {
    // Send an error response
    echo json_encode(['error' => $e->getMessage()]);
}
?>
