<?php
// Load WordPress environment
require_once('wp-load.php');

// URL of the JSON data
$json_url = 'https://www.propertyfinder.ae/api/pwa/location/list?l_t=TOWER%2CSUBCOMMUNITY%2CC';

// Fetch JSON data from URL
$json_data = file_get_contents($json_url);

// Decode JSON data
$data = json_decode($json_data, true);

if ($data === null) {
    // Handle JSON decoding error
    die("Error decoding JSON data.");
}

// WordPress database global variable
global $wpdb;

// WordPress table name
$table_name = $wpdb->prefix . 'community';

// Loop through JSON data and insert into the WordPress table
foreach ($data as $item) {
    $wpdb->insert(
        $table_name,
        array(
            'ID' => $item['id'],
            'TYPE' => $item['l_t'],
            'NAME' => $item['en_p_n'],
            'SLUG' => $item['en_s'], 
        ),
        array(
            '%s',  
            '%s',  
            '%s',
            '%s', 
        )
    );
}

// Check for errors
if ($wpdb->last_error) {
    // Handle database error
    die("Database error: " . $wpdb->last_error);
} else {
    echo "Data imported successfully.";
}
?>
