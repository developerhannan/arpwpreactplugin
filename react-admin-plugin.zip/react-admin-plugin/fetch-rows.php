<?php
// Load WordPress environment
require_once('../../../wp-load.php');

// Ensure the request is a GET request
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('HTTP/1.0 405 Method Not Allowed');
    echo 'Method Not Allowed';
    exit;
}

// Ensure user is logged in and has the required capability
if (!is_user_logged_in() || !current_user_can('read')) {
    header('HTTP/1.0 403 Forbidden');
    echo 'Forbidden';
    exit;
}

global $wpdb;
$table_name = $wpdb->prefix . 'owner';

// Fetch rows from the table
$results = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);

header('Content-Type: application/json');
echo json_encode($results);
exit;
