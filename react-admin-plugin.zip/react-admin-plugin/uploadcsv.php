<?php
// Include WordPress functionality
define('WP_USE_THEMES', false);
require_once('../../../wp-load.php');

// Check if the user is logged in and has permission
if (!is_user_logged_in() || !current_user_can('manage_options')) {
    http_response_code(403);
    die('Unauthorized access');
}

// Check if a file is uploaded
if ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    die('Error uploading file');
}

// Get the uploaded file
$csv_file = $_FILES['csv_file']['tmp_name'];

// Get the field mapping and default values from the request
$field_mapping = json_decode($_POST['field_mapping'], true);
$default_values = json_decode($_POST['default_values'], true);

if (!$field_mapping) {
    # http_response_code(400);
   # die('Invalid field mapping');
    $default_values = [];
}

if (!$default_values) {
    $default_values = [];
}

// Open the CSV file for reading
if (($handle = fopen($csv_file, 'r')) !== false) {
    // Get the CSV headers
    $headers = fgetcsv($handle, 1000, ',');

    // Iterate through each row in the CSV file
    while (($data = fgetcsv($handle, 1000, ',')) !== false) {
        $row = array_combine($headers, $data);
        $insert_data = [];

        // Map CSV data to database fields
        foreach ($field_mapping as $db_field => $csv_header) {
            if (isset($row[$csv_header])) {
                $insert_data[$db_field] = $row[$csv_header];
            } elseif (isset($default_values[$db_field])) {
                $insert_data[$db_field] = $default_values[$db_field];
            } else {
                // If no mapping or default value is provided, skip this field
                http_response_code(400);
                die('Field not mapped: ' . $db_field);
            }
        }

        // Insert data into wp_customer table
        $wpdb->insert(
            'wp_owner',
            $insert_data
        );
    }
    fclose($handle);
    echo 'CSV data imported and mapped successfully';
} else {
    http_response_code(500);
    echo 'Error opening CSV file';
}
?>
